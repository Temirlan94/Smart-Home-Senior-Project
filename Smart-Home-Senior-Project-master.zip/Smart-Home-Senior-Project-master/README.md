# Smart Home Senior Project
This is our senior project in Middle East Technical University. That is about Smart Home Prototype on Arduino board. 
The project dividing 5 parts:
  1. Arduino and Circuit Impelementation and Coding
  2. Server Implementation
  3. Android Implementation
  4. Web Page and Database Implementation
  5. R Coding and Calculations
  
We are still continuing to develop the project. After 3 months we will finish the all assignments about this project.
 
Included Source Code:
  1. Arduino Source Code
  2. R Server Connection and Basic Calculation
  3. PHP Web Service Code
  4. Database Tables
  
  
  
 
